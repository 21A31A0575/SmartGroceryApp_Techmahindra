import { Component } from '@angular/core';

@Component({
  selector: 'app-customer-cart',
  standalone: true,
  imports: [],
  templateUrl: './customer-cart.component.html',
  styleUrl: './customer-cart.component.css'
})
export class CustomerCartComponent {

}
